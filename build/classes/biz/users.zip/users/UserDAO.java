package biz.users;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class UserDAO {
	/* 커넥션 풀 사용 */
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
	
	public void dbConn() {
		try {
			Context initctx = new InitialContext();
			System.out.println("1. Context 생성 성공!!");
			Context envctx = (Context)initctx.lookup("java:comp/env");
			System.out.println("2. Context 환경생성 성공!!");
			DataSource ds = (DataSource) envctx.lookup("jdbc/pool");
			System.out.println("3. DataSource 찾기 성공!!");
			conn = ds.getConnection();
			System.out.println("4. DB접속 성공!!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	// end of dbConn()
	
	public UserVO getUser(String id, String password) {
		UserVO user = null;
		try {
			// 0. DB 접속
			dbConn();
			// 1. SQL
			String sql = "select * from shilla_users where email = ? and password = ?";
			// 2. PreparedStatement
			pstmt = conn.prepareStatement(sql);
			// ?
			pstmt.setString(1, id);
			pstmt.setString(2, password);
			
			// 3. 실행
			rs = pstmt.executeQuery();
			// 4. 사용
			if(rs.next()) {
				user = new UserVO();
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name"));
			}		
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
		// 리턴
		return user;
	}	// end of getuser()
	
	public void insertUser(UserVO bean) {
		dbConn();
		try {
			// 1. SQL
			String sql = "insert into shilla_users values(?,?,?,?,?,?,'user')";
			// 2. ?
			pstmt = conn.prepareStatement(sql);
			// 매핑
			pstmt.setString(1, bean.getEmail());
			pstmt.setString(2, bean.getPassword());
			pstmt.setString(3, bean.getName());
			pstmt.setString(4, bean.getGender());
			pstmt.setString(5, bean.getBirth());
			pstmt.setString(6, bean.getTel());
			// 3. 실행
			pstmt.executeUpdate();
			// 4. 자원반납
			rs.close();
			pstmt.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean EmailCheck(String email) {
		boolean checkemail = false;
		try {
			dbConn();
			String sql = "select COUNT(*) AS count from shilla_users where email = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, email);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				int count = rs.getInt("count");
				if(count > 0) {
					checkemail = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return checkemail;
	}
	
	
	
}	// end of class
